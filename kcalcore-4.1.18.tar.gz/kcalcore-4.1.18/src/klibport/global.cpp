
#include "kcalendarsystem.h"

#include "global.h"

KCalendarSystem* calendarsystem = KCalendarSystem::create("gregorian");
