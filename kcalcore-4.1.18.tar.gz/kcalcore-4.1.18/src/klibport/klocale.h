#ifndef _KLOCALE_H_
#define _KLOCALE_H_

#include <meego_port.h>

#endif
