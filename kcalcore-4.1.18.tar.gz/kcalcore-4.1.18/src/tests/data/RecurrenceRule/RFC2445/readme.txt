All RRULE examples from RFC 2445. Two examples are wrong in the RFC because 
they didn't consider that UNTIL was given in UTC, not in local time.
